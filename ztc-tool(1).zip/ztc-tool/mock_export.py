"""
Mock downstream exports. These stand in for a real Banner/SIS integration
for the demo — same shape of output, no live system connection. Swapping
these for a real Banner web service call is the next step after the MVP.
"""
import csv
from pathlib import Path
from db import all_sections

EXPORT_DIR = Path(__file__).parent / "mock_exports"
EXPORT_DIR.mkdir(exist_ok=True)


def export_banner_mis():
    """Mimics the MIS data file a college would submit to CCCCO, keyed on
    the XB12 element."""
    path = EXPORT_DIR / "banner_mis_export.csv"
    rows = all_sections()
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["SECTION_NUMBER", "COURSE_ID", "TERM", "XB12_CODE"])
        for r in rows:
            writer.writerow([r["section_number"], r["course_id"], r["term"], r["xb12_code"]])
    return path


def export_course_schedule():
    """Mimics the feed that would mark ZTC/LTC on the public course schedule."""
    path = EXPORT_DIR / "course_schedule_export.csv"
    rows = all_sections()
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["SECTION_NUMBER", "COURSE_ID", "TERM", "INSTRUCTOR", "SCHEDULE_MARKING"])
        for r in rows:
            writer.writerow([r["section_number"], r["course_id"], r["term"], r["instructor"], r["schedule_marking"]])
    return path


def export_bookstore():
    """Mimics the feed a bookstore would need for commercial-textbook sections
    (stretch goal — only sections with an ISBN show up here)."""
    path = EXPORT_DIR / "bookstore_export.csv"
    rows = [r for r in all_sections() if r.get("isbn")]
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["SECTION_NUMBER", "COURSE_ID", "TERM", "ISBN"])
        for r in rows:
            writer.writerow([r["section_number"], r["course_id"], r["term"], r["isbn"]])
    return path
