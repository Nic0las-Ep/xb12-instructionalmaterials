"""
XB12 classification logic.

Codes below are the CCCCO XB12 "Instructional-Material-Cost" data element,
Summer 2024 revision (7 codes: A, C, D, E, F, G, Y — code B was retired).

Reference: California Community Colleges Management Information System
Data Element Dictionary, XB12.

    A - Section has no associated course material
    C - Section has course material costs, none of which are passed to students
    D - Section has low course material costs (as defined locally)
    E - Section uses only no-cost OER course material
    F - Section uses only no-cost digital course material that does not meet
        OER guidelines
    G - Section uses a mix of no-cost OER and other cost-bearing resources,
        but no costs are passed to the student
    Y - Section does not meet no-cost or low-cost course material criteria

Schedule marking:
    ZTC (Zero Textbook Cost): codes A, C, E, F, G
    LTC (Low Textbook Cost):  code D
    (neither): code Y
"""

from dataclasses import dataclass

# Locally-defined low-cost threshold (dollars). Colleges set this themselves —
# De Anza's specific number should be confirmed with Shagun; $50 is used
# elsewhere (e.g. Cerritos) as a placeholder default. Change this one value
# to match your college's policy.
LOW_COST_THRESHOLD = 50.00

XB12_LABELS = {
    "A": "No associated course material",
    "C": "Has cost, but not passed on to students",
    "D": "Low course material cost (locally defined)",
    "E": "No-cost OER material only",
    "F": "No-cost digital material only (non-OER)",
    "G": "Mix of no-cost OER and cost-bearing material, but no cost passed to student",
    "Y": "Does not meet no-cost or low-cost criteria",
}

ZTC_CODES = {"A", "C", "E", "F", "G"}
LTC_CODES = {"D"}

# Per CCCCO Data Element Dictionary, XB12 "Processing Edits / FIELD CHECK":
# these are the only valid codes as of the Summer 2024 revision. Code B
# ("no-cost digital instructional material") was retired that revision and
# split into E/F/G. Anything outside this set (e.g. a stray "Z") is a data
# error, not a real category.
VALID_CODES = {"A", "C", "D", "E", "F", "G", "Y"}


@dataclass
class FacultyInput:
    """Raw answers collected from the faculty intake form."""
    has_material: bool           # Does this section require any course material?
    material_is_oer: bool        # Is it (or is part of it) OER-licensed?
    material_is_free_non_oer: bool  # Free digital material that isn't OER (code F territory)
    cost_passed_to_student: bool # Does the student actually pay anything?
    estimated_cost: float        # Dollar estimate, 0 if free
    mixed_oer_and_paid: bool = False  # Mix of OER + paid resources, no cost passed to student


def classify(entry: FacultyInput) -> str:
    """Return the XB12 code for a given faculty submission."""

    if not entry.has_material:
        return "A"

    if entry.mixed_oer_and_paid and not entry.cost_passed_to_student:
        return "G"

    if not entry.cost_passed_to_student:
        # Has material, no cost passed to student — decide OER vs non-OER vs "has cost but absorbed"
        if entry.material_is_oer:
            return "E"
        if entry.material_is_free_non_oer:
            return "F"
        return "C"

    # Cost IS passed to the student from here on
    if entry.estimated_cost <= LOW_COST_THRESHOLD:
        return "D"

    return "Y"


def schedule_marking(code: str) -> str:
    if code in ZTC_CODES:
        return "ZTC"
    if code in LTC_CODES:
        return "LTC"
    return ""


if __name__ == "__main__":
    # Quick smoke tests
    cases = [
        FacultyInput(has_material=False, material_is_oer=False, material_is_free_non_oer=False,
                     cost_passed_to_student=False, estimated_cost=0),
        FacultyInput(has_material=True, material_is_oer=True, material_is_free_non_oer=False,
                     cost_passed_to_student=False, estimated_cost=0),
        FacultyInput(has_material=True, material_is_oer=False, material_is_free_non_oer=True,
                     cost_passed_to_student=False, estimated_cost=0),
        FacultyInput(has_material=True, material_is_oer=False, material_is_free_non_oer=False,
                     cost_passed_to_student=True, estimated_cost=30),
        FacultyInput(has_material=True, material_is_oer=False, material_is_free_non_oer=False,
                     cost_passed_to_student=True, estimated_cost=150),
    ]
    for c in cases:
        code = classify(c)
        print(code, XB12_LABELS[code], "->", schedule_marking(code))
