from flask import Flask, render_template, request, redirect, url_for, send_file

from classify import FacultyInput, classify, schedule_marking, XB12_LABELS
from db import init_db, save_section, find_prior_term, all_sections
from mock_export import export_banner_mis, export_course_schedule, export_bookstore

app = Flask(__name__)
init_db()


@app.route("/", methods=["GET"])
def index():
    return render_template("form.html", prior=None, xb12_labels=XB12_LABELS)


@app.route("/lookup", methods=["POST"])
def lookup():
    """AJAX-free pre-population: re-render the form filled in from the most
    recent submission for this course, if one exists. Matches on course_id
    (Subject + Course Number) only — CRN never rolls over between terms and
    Banner doesn't require the same instructor term to term, so instructor
    is shown but not used as a match key."""
    course_id = request.form.get("course_id", "").strip()
    instructor = request.form.get("instructor", "").strip()
    prior = find_prior_term(course_id) if course_id else None
    return render_template(
        "form.html",
        prior=prior,
        prefill_course_id=course_id,
        prefill_instructor=instructor,
        xb12_labels=XB12_LABELS,
    )


@app.route("/submit", methods=["POST"])
def submit():
    f = request.form

    entry = FacultyInput(
        has_material=f.get("has_material") == "yes",
        material_is_oer=f.get("material_type") == "oer",
        material_is_free_non_oer=f.get("material_type") == "free_non_oer",
        cost_passed_to_student=f.get("cost_passed") == "yes",
        estimated_cost=float(f.get("estimated_cost") or 0),
        mixed_oer_and_paid=f.get("material_type") == "mixed",
    )

    code = classify(entry)
    marking = schedule_marking(code)

    save_section({
        "section_number": f.get("section_number", "").strip(),
        "course_id": f.get("course_id", "").strip(),
        "term": f.get("term", "").strip(),
        "instructor": f.get("instructor", "").strip(),
        "has_material": entry.has_material,
        "material_is_oer": entry.material_is_oer,
        "material_is_free_non_oer": entry.material_is_free_non_oer,
        "mixed_oer_and_paid": entry.mixed_oer_and_paid,
        "cost_passed_to_student": entry.cost_passed_to_student,
        "estimated_cost": entry.estimated_cost,
        "isbn": f.get("isbn", "").strip() or None,
        "oer_source": f.get("oer_source", "").strip() or None,
        "xb12_code": code,
        "schedule_marking": marking,
    })

    return render_template(
        "result.html",
        code=code,
        label=XB12_LABELS[code],
        marking=marking or "None",
        section_number=f.get("section_number"),
        course_id=f.get("course_id"),
    )


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", sections=all_sections())


@app.route("/export/<kind>")
def export(kind):
    if kind == "banner":
        path = export_banner_mis()
    elif kind == "schedule":
        path = export_course_schedule()
    elif kind == "bookstore":
        path = export_bookstore()
    else:
        return "Unknown export", 404
    return send_file(path, as_attachment=True)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
