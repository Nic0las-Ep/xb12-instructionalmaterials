# XB12 / Instructional Materials Cost Tool — MVP (v2)

Built for the "XB12 and Instructional Materials Tool" challenge (De Anza
College, sponsor Shagun Kaur). Updated after receiving real historical
data, the actual survey template, the Banner scheduling manual, and the
official CCCCO XB12 Data Element Dictionary.

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000 — the database ships pre-seeded with 520
real De Anza sections (Fall 25, Winter 26, Spring 26), so pre-population
works immediately without any extra steps.

To re-seed from scratch or with a newer export:

```bash
python3 import_seed_data.py /path/to/Raw_ZTC_Data__De_Anza.xlsx
```

## What changed in this version

**Pre-population match key fixed.** Originally matched on course + instructor.
The Banner Manual confirms CRN is regenerated fresh every term (you type
"ADD" and Banner assigns a new one), so CRN was never usable as a cross-term
key — but it also showed Banner doesn't require the same instructor to teach
a course from term to term. `find_prior_term()` now matches on **course_id
(Subject + Course Number) alone**; instructor is shown as context, not used
for matching.

**Seeded with real data.** `import_seed_data.py` loads
`Raw_ZTC_Data__De_Anza.xlsx` (521 real sections) into the database as
historical records. Each row only carries a section identity and its final
XB12 code — the underlying answers (cost, OER title, etc.) aren't in the raw
export, so seed-sourced pre-population only pre-fills the code-related
fields. The dashboard labels rows "Historical" vs. "Faculty submission" so
it's clear which is which.

**Invalid-code validation added.** The official CCCCO Data Element
Dictionary (`xb12.pdf`) lists the only valid XB12 values as **A, C, D, E, F,
G, Y** (code B was retired in the Summer 2024 revision). `classify.py` now
exposes this as `VALID_CODES`, and the import script checks every row
against it. One real row in the Fall 25 sheet (ASTR-D010., CRN 27731) is
tagged `OERZ` — confirmed a data-entry error, not a real category — and is
skipped on import with a warning rather than silently imported.

**Classification logic validated against real outcomes.** The real data's
code distribution: E (OER) 273, F (free non-OER) 123, D (low-cost) 64, C
(cost absorbed) 39, A (no material) 15, Y (standard cost) 6, G (mixed) 1.
This confirms the seven-code scheme in `classify.py` matches what the
college is actually reporting.

## What's in scope for this MVP

- Faculty intake form (`/`) — course, term, instructor, material details.
- Automatic XB12 classification (`classify.py`), CCCCO Summer 2024 codes.
- Pre-population by course_id, backed by 520 real historical sections.
- Dashboard (`/dashboard`) listing everything on file, seed and live.
- Mock exports (CSV) standing in for Banner MIS, course schedule, bookstore.

## What's explicitly NOT built (by design, for the deadline)

- Real integration with Banner, Colleague, PeopleSoft, or Workday. The
  Banner Manual confirms XB12 doesn't appear anywhere in the standard
  section-creation screens (SSASECT, SIAASGN, SSAACCL) — where/how it's
  actually entered in Banner is still an open question for the sponsor.
- Real bookstore system integration.
- Equity/success dashboard tie-in (would need the Chabot/Alex Karan
  dashboard materials — link is in `Helpful_Links.docx`).
- Chatbot-style UI — plain form for speed; a conversational front-end can
  sit on top of the same `classify()` function later.
- Auth / multi-college support — single SQLite file, no login.

## Still open — confirm with the sponsor before/at demo

1. Is the bookstore piece truly out of scope, or is there one detail worth
   mocking?
2. What does judging weight most — integration depth, faculty UX, or the
   compliance/impact story?
3. Is there a richer version of the historical data (with cost/OER-title
   detail), or should the tool assume final-code-only going forward?
4. Where does XB12 actually get entered/reported in Banner, if not through
   the standard scheduling screens?
5. Any data-handling constraints for this dataset in a public demo setting?
