import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "sections.db"
DB_PATH.parent.mkdir(exist_ok=True)


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            section_number TEXT,
            course_id TEXT NOT NULL,
            term TEXT NOT NULL,
            instructor TEXT,
            has_material INTEGER,
            material_is_oer INTEGER,
            material_is_free_non_oer INTEGER,
            mixed_oer_and_paid INTEGER,
            cost_passed_to_student INTEGER,
            estimated_cost REAL,
            isbn TEXT,
            oer_source TEXT,
            xb12_code TEXT NOT NULL,
            schedule_marking TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'faculty',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def save_section(data: dict):
    """Save a full faculty submission (all detail fields present)."""
    conn = get_conn()
    conn.execute("""
        INSERT INTO sections (
            section_number, course_id, term, instructor,
            has_material, material_is_oer, material_is_free_non_oer,
            mixed_oer_and_paid, cost_passed_to_student, estimated_cost,
            isbn, oer_source, xb12_code, schedule_marking, source
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'faculty')
    """, (
        data["section_number"], data["course_id"], data["term"], data["instructor"],
        int(data["has_material"]), int(data["material_is_oer"]), int(data["material_is_free_non_oer"]),
        int(data["mixed_oer_and_paid"]), int(data["cost_passed_to_student"]), data["estimated_cost"],
        data.get("isbn"), data.get("oer_source"), data["xb12_code"], data["schedule_marking"],
    ))
    conn.commit()
    conn.close()


def save_seed_section(course_id: str, term: str, section_number: str, xb12_code: str, schedule_marking: str):
    """Save a historical record imported from real De Anza data. Only the
    section identity and final XB12 code are known — no underlying detail
    fields (cost, OER title, etc.), since the raw export doesn't include
    them. Used to power pre-population and to validate classify() against
    real outcomes."""
    conn = get_conn()
    conn.execute("""
        INSERT INTO sections (section_number, course_id, term, xb12_code, schedule_marking, source)
        VALUES (?, ?, ?, ?, ?, 'seed')
    """, (section_number, course_id, term, xb12_code, schedule_marking))
    conn.commit()
    conn.close()


def find_prior_term(course_id: str, instructor: str = None):
    """Look up the most recent prior submission for this course, for the
    'same as last time' pre-population feature.

    Matches on course_id (Subject + Course Number) only. Per De Anza's
    Banner Manual, CRN is regenerated fresh every term and is never a
    valid cross-term match key, and Banner does not require the same
    instructor to teach a course from term to term. Instructor is kept
    as a secondary display field, not part of the match."""
    conn = get_conn()
    row = conn.execute("""
        SELECT * FROM sections
        WHERE course_id = ?
        ORDER BY created_at DESC
        LIMIT 1
    """, (course_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def all_sections():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM sections ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]
