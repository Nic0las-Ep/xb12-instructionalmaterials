"""
Import the real De Anza historical section data (Raw_ZTC_Data__De_Anza.xlsx)
into the app's database as seed rows, for pre-population testing and to
validate classify.py against real outcomes.

Usage:
    python3 import_seed_data.py /path/to/Raw_ZTC_Data__De_Anza.xlsx

Each row's OER_CODE column (e.g. "OERD", "OERE") has the XB12 letter as its
last character. Rows with a code outside classify.VALID_CODES are reported
and skipped rather than imported, since they're data errors (see the OERZ
row found in the Fall 25 sheet: not a valid CCCCO code).
"""
import sys
import openpyxl

from classify import VALID_CODES, schedule_marking
from db import init_db, save_seed_section

# Banner term code -> (year, quarter code, school code); school code 2 = De Anza.
# Not strictly needed for the import, but documented here since it's the
# same term-code scheme the Banner Manual describes.
TERM_LABELS = {
    "202522": "Fall 2025",
    "202632": "Winter 2026",
    "202642": "Spring 2026",
}


def run(path: str):
    init_db()
    wb = openpyxl.load_workbook(path, data_only=True)

    imported = 0
    skipped = []

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        header = [h for h in rows[0]]
        idx = {name: i for i, name in enumerate(header) if name}

        for row in rows[1:]:
            oer_code = row[idx["OER_CODE"]] if "OER_CODE" in idx and idx["OER_CODE"] < len(row) else None
            if not oer_code:
                continue

            code = str(oer_code).replace("OER", "").strip().upper()
            term = str(row[idx["TERM"]])
            subject = str(row[idx["SUBJECTCODE"]]).strip()
            crseno = str(row[idx["CRSENO"]]).strip()
            crn = str(row[idx["CRN"]]) if "CRN" in idx else ""
            course_id = f"{subject}-{crseno}"

            if code not in VALID_CODES:
                skipped.append((sheet_name, course_id, term, crn, oer_code))
                continue

            save_seed_section(
                course_id=course_id,
                term=TERM_LABELS.get(term, term),
                section_number=crn,
                xb12_code=code,
                schedule_marking=schedule_marking(code),
            )
            imported += 1

    print(f"Imported {imported} historical sections.")
    if skipped:
        print(f"Skipped {len(skipped)} row(s) with invalid codes:")
        for sheet_name, course_id, term, crn, oer_code in skipped:
            print(f"  {sheet_name}: {course_id} (term {term}, CRN {crn}) -> {oer_code}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 import_seed_data.py /path/to/Raw_ZTC_Data__De_Anza.xlsx")
        sys.exit(1)
    run(sys.argv[1])
